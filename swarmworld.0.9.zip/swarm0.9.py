# swarm3.5 : 8.1.20
'''
Version 3.5:
    - make food sprite larger and support food amt; each collide reduces food_amt
    - change the gold appearance to reflect loss
    - adds logic so if a bot is surrounded by bots of different swarm, it loses health

Version 3.4:
      - adds health to the bots. health hit when collision with barriers
      - if health goes to zero, bot dies.
      -  idea for game with RL: swarm to get to their new zone with most surviving bots wins

      - adds names to the swarms
      - passes swarm ref to bots so bots can make callbacks to swarm controller
      - when bot is created, it gets an id for itself
      - BOTS_CAN_DIE  : boolean. if True bot dies if health <= 0
         each time bot hits barrier it loses 1 health
      - replaces blockList with block_group which holds all blocks.
         The group can return the list of all block sprites using .sprites()
      - each swarm now has an id number for referencing
      - can now select swarms using F1 OR (new) CTL-1, CTL-2, CTL-3
      - config.yaml : file for game configuration. can set
      -- number of swarms and properties (health, size, center, name
      -- number of barriers and location
      -- game config: BOTS_CAN_DIE = True|False  - Collision w/barrier decreases
         health by 1: True means bot dies if health goes to zero
      - adds food_group as group for Food sprites. if bot collides, gets +1 health

version 3.3:
    - Uses Pygame functionality: Swarms are now Groups and Bots and barriers are Sprites
        Makes it much easier to do Collision Detection.

    - Each Swarm (subclass of Group) knows all its Bots. The Swarm has a center and a range
        that defines an envelope around the swarm. When you constuct a Swarm one passes the number
        of bots that each Swarm contains and the swarm object creates each bot and make sure they
        do not collide.

    - The code uses swarmList to hold each swarm. Then, each game cycle, all the action occurs with:

        for swarm in swarmList:
            swarm.update_bots(block_group)  # move em around ; compute new random positions

        redrawGameWindow(swarmList, block_group)

        where block_group is the Group holding all the barrier sprites

    - To get a swarm to move press F1, F2 or F3 for swarm 1, 2 or 3 and then press a
numeric key to reset the swarm center. All bots will then move to the envelope
surrounding the new swarm center. Each bot computes the angle needed to get to the new
swarm center. However, to avoid a straight line zoom to the new swarm center, the actual angle
is modified slightly (randomly) to get the bots to head to the center on a wiggly course.

    - If a bot moves to a new x,y position and finds that it collides with another bot or with a barrier,
the bot is returned to its previous position. In the next game cycle, it chooses another random
move and eventually finds its way around a barrier.

'''
import pygame
import math
import random
import numpy as np
import os
import yaml

BLACK = (0, 50, 0)
GRAY = (169, 169, 169)
WHITE = (255, 255, 255)
BLUE = (100, 40, 200)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
MAROON = (200, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 140, 0)
GOLD = (255, 215, 0)
ORANGE_RED = (255, 69, 0)

WINDOW_HEIGHT = 900
WINDOW_WIDTH = 900
DRAW_SWARM_CENTER = False

# CLOCK controls speed - FPS = frames per second
CLOCK = pygame.time.Clock()
FPS = 30  # game speed frames per second

# for dividing screen into 9 zones 1-9
NUM_ROWS_AND_COLS = 3
blockx = WINDOW_WIDTH / NUM_ROWS_AND_COLS
blocky = WINDOW_HEIGHT / NUM_ROWS_AND_COLS

BOT_SIZE = 8
SWARM_ON_MOVE = False  # set when most of swarm is outside envelope
swarmList = []  # List of different Swarms

pygame.init()

# set display window size
SCREEN = pygame.display.set_mode((WINDOW_HEIGHT, WINDOW_WIDTH))

# set the pygame window name
pygame.display.set_caption('Swarm World')

# Set up for text info display
font = pygame.font.Font('freesansbold.ttf', 16)

# Modes: can turned on and off via Key Press
CIRCLE_MODE = False  # todo: have bots swarm in circles

# images for game
# background is bg - needs to cover the screen
bg = pygame.image.load('bg.jpg')
grass = pygame.image.load('grass.jpg')

# version 3.4 - adds health and death
BOTS_CAN_DIE = False  # can set in config file
DEFAULT_HEALTH = 10  # can set helath for a swarm in config
NEXT_BOT_ID = 0
NEXT_SWARM_ID = 0


# Utility Functions  ------ for polar coordinate implementation---
def genPointInCircle(center_tup, radius_max):
    'return tuple (x,y) inside circle '
    cx = center_tup[0]
    cy = center_tup[1]
    angle = random.random() * 2 * math.pi
    ' using sqrt pulls toward center'
    radius = radius_max * math.sqrt(random.random())
    # radius = radius_max * (random.random())
    return (cx + radius * math.cos(angle), cy + radius * math.sin(angle))


# use to set up x and y changes into going to a target
def getZeroBasedXYTupForAngleBasedMove(target, origin):
    return tuple(np.subtract(target, origin))


def getAngleRadsToTarget(x, y):
    'assumes from = (0,0) '
    # angle from bot to a destination (y,x)
    return math.atan2(y, x)  # note atan2 wants y,x as ordering of parms


def getAngleFromToTuples(pt_from, pt_to):
    origin_tup = getZeroBasedXYTupForAngleBasedMove(pt_to, pt_from)
    'use origin tuple to compute angle'
    return getAngleRadsToTarget(origin_tup[0], origin_tup[1])


# ------------- END Utility Functions  ------ --------------


# CLASS Bot : the little creature that swarms

# CLASS Barrier : define barrier as a kind of pygame.Rect
class Barrier(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x, y, w, h)

    def draw(self):
        global grass
        '''grass = pygame.transform.scale(grass,(self.w,self.h) )
        grass_rect = grass.get_rect()
        grass_rect.move( (400,400))
        SCREEN.blit(grass, grass_rect)
        '''
        # barrier draw --------
        # pygame.draw.rect(SCREEN, GRAY, (self.x, self.y, self.w, self.h))
        pygame.draw.rect(SCREEN, GRAY, self.rect)

    def update(self):
        '''so Barriers can play in sprite-land'''
        self.draw()


# CLASS Food : define barrier as a kind of pygame.Rect
class Food(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h, food):
        pygame.sprite.Sprite.__init__(self)
        self.rect = pygame.Rect(x, y, w, h)
        self.red = 255
        self.green = 215
        self.blue = 0
        self.max_food = food
        self.food_remaining = food

    def draw(self):
        red_draw = max(0, int(self.red * (self.food_remaining / self.max_food) ) )
        green_draw = max(0, int(self.green * (self.food_remaining / self.max_food) ) )
        pygame.draw.rect(SCREEN, (red_draw, green_draw,0), self.rect)

    def update(self):
        '''so Food can play in sprite-land'''
        self.draw()


# CLASS BlockGroup  ---  holds refs to all the Barrier (sprites)
#                        allows easy CD with Barriers
class BlockGroup(pygame.sprite.Group):
    def __init__(self):
        pygame.sprite.Group.__init__(self)


# CLASS: FoodGroup -- holds refs to food-source sprites
#                     collision increases health
class FoodGroup(pygame.sprite.Group):
    def __init__(self):
        pygame.sprite.Group.__init__(self)


# CLASS Bot -------------------
class Bot(pygame.sprite.Sprite):
    global NEXT_BOT_ID

    def __init__(self, x, y, botsize, color, health, swarm):
        pygame.sprite.Sprite.__init__(self)
        global NEXT_BOT_ID
        self.image = pygame.Surface((botsize, botsize))
        self.image.fill(color)
        self.x = x
        self.y = y
        # future: do we need self.x, self,y since the rect knows this
        self.rect = pygame.Rect(x, y, botsize, botsize)
        self.color = color
        self.botsize = botsize
        # v 3.4
        self.health = health
        self.swarm = swarm

        self.id = NEXT_BOT_ID
        NEXT_BOT_ID += 1

    def pt_tup(self):
        'returns  x,y position as tuple for numpy tuple computations'
        x = self.x
        y = self.y
        return (x, y)

    def draw(self):
        if self.health <= 4:  # show weakened bot near death
            cx = int(self.x + self.botsize / 2 )
            cy = int(self.y + self.botsize / 2  )
            pygame.draw.rect(SCREEN, self.color, self.rect, 1)
            pygame.draw.circle(SCREEN,RED, (cx, cy), int(self.botsize/6), 1)
        else:
            pygame.draw.rect(SCREEN, self.color, self.rect, 0)

    def update(self):
        '''when swarm update is called - passed on the bots'''
        self.draw()

    def collide_with_blockGroup(self, block_group):

        'if collide with any block, returns the block ref or None'
        hit_block = pygame.sprite.spritecollideany(self, block_group)

        # adding decrease health when hit block
        if hit_block != None:
            self.health += -1
            #todo: if block_group for food, then decrement food for the hit_block
            return True
        else:
            return False

    def check_food_find(self, food_group):
        hit_block = pygame.sprite.spritecollideany(self, food_group)
        if hit_block != None:
            # bot intersecting food gives health to bot and reduces food
            if hit_block.food_remaining > 0:
                self.health += 1
                hit_block.food_remaining += -1
                print("%s  %d says YUM! Health= %d" % (self.swarm.name, self.id, self.health))

    def collide(self, botList):

        if len(botList) == 0: return False

        for bot in botList:
            # don't compare with self
            if self is bot:
                continue
            if pygame.sprite.collide_rect(self, bot):
                return True
        return False


# ----------------- end bot Class def ---------------------


# ----------------- BEGIN SWARM DEF --------------
''' the Swarm (instance) is responsible for managing its bots.
    Bots frolic randomly in the Swarm's circular 2D space envelope.
    Swarm expansion and contraction depend on the swarm.range
    Modify the swarm.center to swarm to a new location.
    Keys 1-9 move the swarm.center to 9 locations.
    Plus/Minus keys expand/contract the swarm.range 
    '''


class Swarm(pygame.sprite.Group):
    global DEFAULT_HEALTH

    def __init__(self, nbots, center_pt, color, name, health):
        global NEXT_SWARM_ID
        pygame.sprite.Group.__init__(self)

        self.center = center_pt
        self.name = name

        # no ++ in Python
        NEXT_SWARM_ID += 1
        self.id = NEXT_SWARM_ID

        self.botsize = 8  # fixed
        self.botarea = self.botsize * self.botsize
        self.color = color
        self.nbots = nbots
        self.health = health  # default for all bots in the swarm

        # compute swarm envelope radius based on area of bots - guarantee a fit
        # when milling arouond the bots move randomly in the swarm envelope
        self.radius = int(math.sqrt(self.botarea * nbots / math.pi) * 2)

        # swarm creates all its bots
        self.create_bots(nbots)

    def create_bots(self, nbots):
        ''' creates all bots in the swarm'''
        # position bots randomly within envelope
        for _ in range(nbots):
            r = self.radius * math.sqrt(random.random())
            theta = random.random() * 2 * math.pi
            # random point in swarm circle
            x = int(self.center[0] + r * math.cos(theta))
            y = int(self.center[1] + r * math.sin(theta))

            # create temp bot to test for collision: if ok, add to swarm.sprites()
            # pass ref to self so bot knows its main swarm - can call back
            temp_bot = Bot(x, y, self.botsize, self.color, self.health, self)

            # keep looking for a free spot - assumes correct range(radius)
            # if envelope is too small, will crash app

            while temp_bot.collide(self.sprites()):
                r = self.radius * math.sqrt(random.random())
                theta = random.random() * 2 * math.pi
                # new random point in swarm circle
                temp_bot.x = self.center[0] + r * math.cos(theta)
                temp_bot.y = self.center[1] + r * math.sin(theta)
                temp_bot.rect = pygame.Rect(temp_bot.x, temp_bot.y, self.botsize, self.botsize)

            # self.botlist.append(temp_bot)    # remove? kills game??
            self.add(temp_bot)  # added?? two models same time
            # 7.23 4p - !! the add to Group got them mving

    def genBotTupleList(self):
        ''' for centroid calc. need points as tuple list'''
        tup_list = []
        for bot in self.sprites():
            tup_list.append(bot.pt_tup())
        return tup_list

    def update_bots(self, block_group):
        'Called Everyt Game cycle -- move all the bots : swarming'
        global SWARM_ON_MOVE, swarmList, CIRCLE_MODE, BOTS_CAN_DIE  # todo: set via keystroke

        # Is swarm on the move? test centroid of swarm with swarm center
        c_pt = self.get_centroid()
        distance = math.sqrt(((c_pt[0] - self.center[0]) ** 2) + ((c_pt[1] - self.center[1]) ** 2))
        SWARM_ON_MOVE = distance > self.radius * 0.35

        if (CIRCLE_MODE):
            pass  # todo: use centroid of swarm to get them moving in oncentric circle
        else:
            # default:  swarm around swarm center
            cx = self.center[0]
            cy = self.center[1]

            for bot in self.sprites():

                # new in v3.4 - bot dies if health <= 0
                if BOTS_CAN_DIE and bot.health <= 0:
                    self.remove(bot)
                    team = bot.swarm.name
                    print("%s bot %d dies..." % (team, bot.id))
                    continue  # back to top of loop

                prev_x = bot.x  # save pos in case of collision
                prev_y = bot.y

                if SWARM_ON_MOVE:
                    # for some subset of bots, add random movement
                    if random.randint(0, 9) < 1:
                        target_tup = genPointInCircle(c_pt, self.radius)
                        bot_tup = bot.pt_tup()
                        theta0 = getAngleFromToTuples(bot_tup, target_tup)
                    else:
                        # aim at point beyond target swarm.center
                        theta0 = getAngleFromToTuples(c_pt, self.center)
                        theta0 += random.uniform(-1.5, 1.5)
                    bot.x += int(5 * math.cos(theta0))
                    bot.y += int(5 * math.sin(theta0))
                    bot.rect = pygame.Rect(bot.x, bot.y, bot.botsize, bot.botsize)

                else:  # random bounce inside swarm envelope
                    r = self.radius
                    theta = random.random() * 2 * math.pi

                    # pick target random point in swarm circle
                    target_tup = genPointInCircle(self.center, self.radius)

                    # compute angle from swarm.center to random target point
                    # if you change the center of swarm (via keypress +,-, bots migrate to new zone
                    theta = getAngleFromToTuples(self.center, target_tup)

                    bot.x += int(5 * math.cos(theta))
                    bot.y += int(5 * math.sin(theta))
                    bot.rect = pygame.Rect(bot.x, bot.y, self.botsize, self.botsize)

                    # is bot outside range of its swarm?  if yes, head toward center.
                    # this keeps bots from wandering too far outside swarm circle
                    # AND, as bonus, will get them to migrate to new area if swarm.center changes

                    # Is Bot outside the swarm envelope?
                    # If yes, aim it toward random point in envelope

                    if math.sqrt((bot.x - cx) ** 2 + (bot.y - cy) ** 2) > self.radius:
                        # compute angle to point within center range
                        target_tup = genPointInCircle(self.center, self.radius)
                        theta = getAngleFromToTuples((bot.x, bot.y), target_tup)

                        # avoid direct beeline to target, add random to theta
                        theta += random.uniform(-0.75, 0.75)
                        bot.x += int(5 * math.cos(theta))
                        bot.y += int(5 * math.sin(theta))
                        # need to update the rect for CD
                        bot.rect = pygame.Rect(bot.x, bot.y, self.botsize, self.botsize)

                ##  -        COLLISION DETECTION  ##############
                # bot vs barriers
                if bot.collide_with_blockGroup(block_group):
                    'undo move'
                    bot.x = prev_x
                    bot.y = prev_y
                    bot.rect = pygame.Rect(bot.x, bot.y, self.botsize, self.botsize)

                # does our bot collide with other bots in our swarm
                # need to check against all the other sprites
                for other_bot in self.sprites():
                    # a bot always collides with itself so ignore that
                    if not other_bot is bot:
                        if bot.rect.colliderect(other_bot.rect):
                            bot.x = prev_x
                            bot.y = prev_y
                            # dual x,y. but for pygame CD need rect adjusted
                            bot.rect = pygame.Rect(bot.x, bot.y, bot.botsize, bot.botsize)
                            # break loop - bot stays still
                            break

                # test collision with other swarms ? -
                for otherSwarm in swarmList:
                    if not self is otherSwarm:
                        hit_list = pygame.sprite.spritecollideany(bot, otherSwarm)
                        if hit_list != None:
                            bot.x = prev_x
                            bot.y = prev_y
                            bot.rect = pygame.Rect(bot.x, bot.y, bot.botsize, bot.botsize)
                            break

                # test collision with food source: +1 health
                bot.check_food_find(food_group)

    def get_centroid(self):
        'determine the centroid (center) of the swarm'
        bot_tup_list = self.genBotTupleList()
        x_coords = [p[0] for p in bot_tup_list]
        y_coords = [p[1] for p in bot_tup_list]
        _len = len(bot_tup_list)

        # all bots may have died so _len will be 0
        if _len <= 0:
            return (0, 0)
        else:
            centroid_x = int(sum(x_coords) / _len)
            centroid_y = int(sum(y_coords) / _len)
            return (centroid_x, centroid_y)


# --- end Swarm class def -----------------

def drawGameTextInfo():
    global text, textRect, SWARM_ON_MOVE

    # display for user   ----------
    mode_msg = "F1=Swarm1, F2=Swarm2: 1-9 to move swarm to regions. Press + or - to expand/contract swarm circle"
    text = font.render(mode_msg, True, RED, BLUE)
    textRect = text.get_rect()
    textRect.center = (400, 20)
    SCREEN.blit(text, textRect)


# KEY Function -- called at end of game loop
def redrawGameWindow(swarmList, block_group, food_group):
    # draw background
    SCREEN.blit(bg, (0, 0))

    # draw Blocks
    block_group.update()

    # draw food sources
    food_group.update()

    # draw all bots
    for swarm in swarmList:
        swarm.update()
        # for bot in swarm.sprites():
        #    bot.draw()

    # Keystroke 'c' to turn on/off draw swarm.center
    for swarm in swarmList:
        if DRAW_SWARM_CENTER:
            c_rect = pygame.Rect(swarm.center_point[0], swarm.center_point[1], 4, 4)
            pygame.draw.rect(SCREEN, GREEN, c_rect, 0)

    drawGameTextInfo()  # options; game info

    # DRAW the bots and text based on all previous draw commands
    pygame.display.update()


def setupSwarmsAndBlocks(config_file):
    global swarmList, block_group, food_group, BOTS_CAN_DIE

    # create Group for Barriers
    block_group = BlockGroup()

    # create Group for Food Sources
    food_group = FoodGroup()

    if os.path.isfile(config_file):
        with open(config_file)  as f:
            docs = list(yaml.load_all(f, Loader=yaml.Loader))
            # assume order
            swarm_list_dict = docs[0]
            barrier_list_dict = docs[1]
            food_list_dict = docs[2]
            game_def_dict = docs[3]

            # set up barriers
            for dict in barrier_list_dict:
                block_group.add(Barrier(dict['x'], dict['y'], dict['w'], dict['h']))

            # set up food sources
            for dict in food_list_dict:
                food_group.add(Food(dict['x'], dict['y'], dict['w'], dict['h'], dict['food']))

            # set up swarms who create their bots
            for d in swarm_list_dict:
                'color comes in as string. need to convert to defined variable'
                yamcolor = d['color']
                health = d['health']

                if yamcolor == 'RED':
                    color = RED
                elif yamcolor == 'BLUE':
                    color = BLUE
                elif yamcolor == 'GREEN':
                    color = GREEN
                elif yamcolor == 'YELLOW':
                    color = YELLOW
                elif yamcolor == 'GOLD':
                    color = GOLD
                elif yamcolor == 'MAROON':
                    color = MAROON
                elif yamcolor == 'BLACK':
                    color = BLACK
                elif yamcolor == 'WHITE':
                    color = WHITE
                elif yamcolor == 'GRAY':
                    color = GRAY
                else:
                    color = ORANGE_RED
                # create and add to list of swarms
                swarmList.append(Swarm(d['nbots'], (d['centerX'], d['centerY']), color, d['name'], d['health']))

            # game parms
            BOTS_CAN_DIE = game_def_dict['BOTS_CAN_DIE']

    else:
        # default if no file found: config.yml

        # create the individual blocks (sprites) and add to  block_group
        y, w, h = (240, 50, 150)
        for x in range(100, 800, 100):
            block = Barrier(x, y, w, h)
            block_group.add(block)

        # create swarm object  : number bots, center and radius of swarm,
        # based on the number of bots, the swarm computes the radius of
        # its swarm envelope.
        swarm1 = Swarm(16, (200, 150), MAROON, "Red League")
        swarm2 = Swarm(18, (700, 700), YELLOW, "Yellow Jackets")
        swarm3 = Swarm(10, (500, 500), GREEN, "Green Machine")
        swarmList = [swarm1, swarm2, swarm3]


def run_game():
    global CLOCK, FPS, DRAW_SWARM_CENTER, swarmList, block_group, food_group

    print("Let's swarm...with version 3.5")
    pygame.init()

    # read config file for swarm and barrier specs
    # if file not found, default is 3 swarms and 6 blocks
    setupSwarmsAndBlocks('config.yaml')

    # ----------  main game loop --------------
    keep_playing = True
    swarm_idx = 0  # default to single swarm in game
    while keep_playing:
        CLOCK.tick(FPS)

        # Check for events - keypress or any software generated events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # required for PyGame. Don't leave out.
                keep_playing = False

            mods = pygame.key.get_mods()
            # Numeric Keys modify swarm.center - swarm moves
            if event.type == pygame.KEYDOWN:
                # function keys refer to swarms F1, F2
                if event.key == pygame.K_F1:
                    swarm_idx = 0
                elif event.key == pygame.K_F2:
                    swarm_idx = 1
                elif event.key == pygame.K_F3:
                    swarm_idx = 2

                # alternate way to select using ctl-1, etc
                # note: convert 1 to 0 which is index into swarmList
                # so that swarm1 is 0th in the swarmList
                # We can handle 9 swarms (1-9) but need to check that
                #  our numeric ctl-key is <= len(swarmList)

                # CTL-1  and 1
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_1 \
                        and len(swarmList) >= 1:
                    swarm_idx = 0
                elif event.key == pygame.K_1:
                    swarmList[swarm_idx].center = (int(blockx * 0.5), int(blocky / 2))

                # CTL-2 and 2
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_2 \
                        and len(swarmList) >= 2:
                    swarm_idx = 1
                elif event.key == pygame.K_2:
                    swarmList[swarm_idx].center = (int(blockx * 1.5), int(blocky / 2))

                # CTL-3 and 3
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_3 \
                        and len(swarmList) >= 3:
                    swarm_idx = 2
                elif event.key == pygame.K_3:
                    swarmList[swarm_idx].center = (int(blockx * 2.5), int(blocky / 2))

                # CTl-4 and 4
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_4 \
                        and len(swarmList) >= 4:
                    swarm_idx = 3
                elif event.key == pygame.K_4:
                    swarmList[swarm_idx].center = (int(blockx * 0.5), int(blocky * 1.5))

                # Ctl-5 and 5
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_5 \
                        and len(swarmList) >= 5:
                    swarm_idx = 4
                elif event.key == pygame.K_5:
                    swarmList[swarm_idx].center = (int(blockx * 1.5), int(blocky * 1.5))

                # ctl-6 and 6
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_6 \
                        and len(swarmList) >= 6:
                    swarm_idx = 5
                elif event.key == pygame.K_6:
                    swarmList[swarm_idx].center = (int(blockx * 2.5), int(blocky * 1.5))

                # ctl-7 and 7
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_7 \
                        and len(swarmList) >= 7:
                    swarm_idx = 6
                elif event.key == pygame.K_7:
                    swarmList[swarm_idx].center = (int(blockx * 0.5), int(blocky * 2.5))

                # ctl-8 and 8
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_8 \
                        and len(swarmList) >= 8:
                    swarm_idx = 7
                elif event.key == pygame.K_8:
                    swarmList[swarm_idx].center = (int(blockx * 1.5), int(blocky * 2.5))

                # ctl-9 and 9
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_9 \
                        and len(swarmList) >= 9:
                    swarm_idx = 8
                elif event.key == pygame.K_9:
                    swarmList[swarm_idx].center = (int(blockx * 2.5), int(blocky * 2.5))

                # ctl0 = swarm idx 9
                elif mods & pygame.KMOD_CTRL and event.key == pygame.K_0 \
                        and len(swarmList) >= 10:
                    swarm_idx = 9

                # replace F1 with Ctl-1, etc

                # PLUS/MINUS on Keypad control size of swarm envelope
                elif event.key == pygame.K_KP_PLUS:
                    swarmList[swarm_idx].radius += 20
                elif event.key == pygame.K_KP_MINUS:
                    swarmList[swarm_idx].radius -= 20
                    # avoid dealing with negative ranges..!!
                    if swarm.radius <= 0:
                        swarm.radius = 1
                # needs work:
                # elif event.key == pygame.K_c:
                #    DRAW_SWARM_CENTER = not DRAW_SWARM_CENTER

        # Every thing gets updated here
        for swarm in swarmList:
            swarm.update_bots(block_group)  # move em around ; compute new random positions

        # after all the bots are positioned - redraw the screen
        redrawGameWindow(swarmList, block_group, food_group)

    # out of the game loop, shut down
    pygame.quit()


# ------------  launch game -----------
run_game()









